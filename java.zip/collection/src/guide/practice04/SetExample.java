package guide.practice04;

import java.util.Scanner;
import java.util.TreeSet;

public class SetExample {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// 코드 작성
		TreeSet<Integer> treeSet = new TreeSet<>();
		int x = 0;
		System.out.println("정수(-1이 입력될 때까지)>>");
		while(x > -1) {
			x = sc.nextInt();
			treeSet.add(x);
		}
		if(treeSet.size() == 0) {
			System.out.println("수가 하나도 없음");
		}
		System.out.println("가장 큰 수 는 : "+treeSet.last());
		System.out.println("시스템 종료");
	}

}
