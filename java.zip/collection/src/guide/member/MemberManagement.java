package guide.member;
 
/**
 * AppBase의 기능을 구현한 자식 class
 * AppBase의 기능을 상속받아 제시된 기능을 완성하시오.
 */
public class MemberManagement  extends AppBase
{	

	@Override
	protected void isRun() {
		System.out.println("프로그램 시작!");
		while(isRun) {
			System.out.println("======================================================");
			System.out.println("1.회원가입 |2.로그인 |3.회원정보|4.회원정보수정|5.회원탈퇴|6.종료");
			System.out.println("======================================================");
			System.out.println("메뉴 선택 > ");
			selectNo = sc.nextInt();
			switch(selectNo){
				case 1 : 
					join();
					break;
				case 2 :
					login();
					break;
				case 3 :
					select();
					break;
				case 4 :
					update();
					break;
				case 5 : 
					delete();
					break;
				case 6 :
					terminate();
					break;
			}
		}
	}

	@Override
	protected void terminate() {
		isRun = false;
		System.err.println("프로그램 종료");
	}

	@Override
	protected void join() {
		System.out.println("== 회원가입 ==");
		System.out.println("아이디를 입력해주세요");
		String mId = sc.next();
		System.out.println("비밀번호를 입력해주세요");
		String mPw = sc.next();
		System.out.println("비밀번호를 한번 더 입력해주세요");
		String rePw = sc.next();

		if(!memberIdCheck(mId) || !mPw.equals(rePw)) {
			System.err.println("사용 할 수 없는 아이디 이거나 비밀번호가 일치하지 않습니다.");
			return;
		}
		
		System.out.println("이름을 입력해주세요");
		String mName = sc.next();
		int mNum = memberList.size();
		Member m = new Member(mNum,mName,mId,mPw,System.currentTimeMillis());
		memberList.add(m);
		System.err.println("회원가입 완료");
	}

	@Override
	protected void login() {
		System.out.println("== 로그인 == ");
		System.out.println("아이디를 입력해주세요 > ");
		String mId = sc.next();
		System.out.println("비밀번호를 입력해주세요 > ");
		String mPw = sc.next();
		
		Member m = new Member(mId, mPw);
		
		if(findMember(m) == null) {
			System.err.println("일치하는 회원 정보가 없습니다.");
			return;
		}
		
		loginMember = m;
		System.err.println("정상적으로 로그인 되었습니다.");
		
		if(loginMember.equals(master)) {
			System.err.println("관리자 계정입니다.");
		}
		
		System.err.println(loginMember);
		
		
	}

	@Override
	protected void select() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void delete() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void deleteMember() {
		// TODO Auto-generated method stub
		
	}
	
}
