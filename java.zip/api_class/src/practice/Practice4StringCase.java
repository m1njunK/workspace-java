package practice;

import java.util.Scanner;

public class Practice4StringCase {

	public static void main(String[] args) {
		String chars = "abcdefghijklmnopqrstuvwxyz";
		String num = "01234569";
		
		Scanner sc = new Scanner(System.in);
		System.out.println("문자나 숫자를 입력해주세요>");
		String str = sc.next();
		str = str.toLowerCase();
		// code 작성
		System.out.println("영어문자 : " + chars.contains(str));
		System.out.println("숫자문자 : " + num.contains(str));
		sc.close();
	}

}
